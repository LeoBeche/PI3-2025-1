cd ..
idf.py -p COM4 -b 460800 flash
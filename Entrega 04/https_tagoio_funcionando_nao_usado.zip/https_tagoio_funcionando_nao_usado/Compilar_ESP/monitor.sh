cd ..
idf.py -p COM4 monitor
/* HTTPS GET Example using plain mbedTLS sockets
 *
 * Contacts the howsmyssl.com API via TLS v1.2 and reads a JSON
 * response.
 *
 * Adapted from the ssl_client1 example in mbedtls.
 *
 * Original Copyright (C) 2006-2016, ARM Limited, All Rights Reserved, Apache 2.0 License.
 * Additions Copyright (C) Copyright 2015-2016 Espressif Systems (Shanghai) PTE LTD, Apache 2.0 License.
 *
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *     http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
#include <string.h>
#include <stdlib.h>
#include "freertos/FreeRTOS.h"
#include "freertos/task.h"
#include "freertos/event_groups.h"
#include "esp_wifi.h"
#include "esp_event.h"
#include "esp_log.h"
#include "esp_system.h"
#include "nvs_flash.h"
#include "protocol_examples_common.h"
#include "esp_netif.h"

#include "lwip/err.h"
#include "lwip/sockets.h"
#include "lwip/sys.h"
#include "lwip/netdb.h"
#include "lwip/dns.h"

#include "esp_tls.h"

#include "cJSON.h"

/* Constants that aren't configurable in menuconfig */
#define WEB_SERVER "www.api.tago.io"
#define WEB_PORT "443"
static char *WEB_URL = "https://api.tago.io/data?token=4d5397ad-decf-4bbe-b99c-8117615eed78";

uint32_t Energia = 0;
uint32_t Queda = 1;

static const char *TAG = "example";

#define HTTP_REQUEST_BUFFER_SIZE 1024 // Adjust size if your JSON grows
static char http_full_request[HTTP_REQUEST_BUFFER_SIZE];

#define JSON_PAYLOAD_BUFFER_SIZE 256 // Adjust size as needed
static char dynamic_json_payload[JSON_PAYLOAD_BUFFER_SIZE];


#define YOUR_DEVICE_TOKEN "4d5397ad-decf-4bbe-b99c-8117615eed78" // Your actual token

extern const uint8_t server_root_cert_pem_start[] asm("_binary_server_root_cert_pem_start");
extern const uint8_t server_root_cert_pem_end[]   asm("_binary_server_root_cert_pem_end");


static void https_get_task(void *pvParameters)
{
    char buf[512];
    int ret, len;

    while(1) {
        esp_tls_cfg_t cfg = {
            .cacert_buf  = server_root_cert_pem_start,
            .cacert_bytes = server_root_cert_pem_end - server_root_cert_pem_start,
        };
        
        struct esp_tls *tls = esp_tls_conn_http_new(WEB_URL, &cfg);
        
        if(tls != NULL) {
            ESP_LOGI(TAG, "Connection established...");
        } else {
            ESP_LOGE(TAG, "Connection failed...");
            goto exit;
        }
        
        size_t written_bytes = 0;
	size_t total_request_len = 0;
        do {

        int json_chars_written = snprintf(dynamic_json_payload, JSON_PAYLOAD_BUFFER_SIZE,
                                          "[\n"
                                          "  {\n"
                                          "    \"variable\": \"Energia\",\n"
                                          "    \"value\": %u,\n" // %u for unsigned int 
                                          "    \"unit\": \"KWh\"\n"
                                          "  },\n"
                                          "  {\n"
                                          "    \"variable\": \"Queda\",\n"
                                          "    \"value\": %u,\n"    // %u for unsigned int
                                          "    \"unit\": \"boolean\"\n"  // Use %% to print a literal %
                                          "  }\n"
                                          "]",
                                          Energia, Queda);
            
            size_t json_len = (size_t)json_chars_written; // Get the actual length of the generated JSON
             
            int header_len = snprintf(http_full_request, HTTP_REQUEST_BUFFER_SIZE,
                                  "POST %s HTTP/1.0\r\n" 
   				  "Host: "WEB_SERVER"\r\n"
   				  "User-Agent: esp-idf/1.0 esp32\r\n"
   				  "Device-Token: 4d5397ad-decf-4bbe-b99c-8117615eed78\r\n"
   				  "Content-Type: application/json\r\n"
                                  "Content-Length: %zu\r\n" // Use %zu for size_t
                                  "\r\n", // Blank line
                                  WEB_URL, json_len);
    // ...
            memcpy(http_full_request + header_len, dynamic_json_payload, json_len); // Use memcpy, no null termination needed mid-string
            http_full_request[header_len + json_len] = '\0'; // Manually null-terminate the final string for logging/strlen on total

            total_request_len = header_len + json_len; // Total bytes to send
  
            ESP_LOGI(TAG, "Sending HTTP Request (total %zu bytes):\n%s", total_request_len, http_full_request);         
    		
            ret = esp_tls_conn_write(tls,http_full_request + written_bytes,total_request_len - written_bytes);

            if (ret >= 0) {
                ESP_LOGI(TAG, "%d bytes written", ret);
                written_bytes += ret;
            } else if (ret != ESP_TLS_ERR_SSL_WANT_READ  && ret != ESP_TLS_ERR_SSL_WANT_WRITE) {
                ESP_LOGE(TAG, "esp_tls_conn_write  returned 0x%x", ret);
                goto exit;
            }
        } while(written_bytes < total_request_len);

        ESP_LOGI(TAG, "Reading HTTP response...");

        do
        {
            len = sizeof(buf) - 1;
            bzero(buf, sizeof(buf));
            ret = esp_tls_conn_read(tls, (char *)buf, len);
            
            if(ret == ESP_TLS_ERR_SSL_WANT_WRITE  || ret == ESP_TLS_ERR_SSL_WANT_READ)
                continue;
            
            if(ret < 0)
           {
                ESP_LOGE(TAG, "esp_tls_conn_read  returned -0x%x", -ret);
                break;
            }

            if(ret == 0)
            {
                ESP_LOGI(TAG, "connection closed");
                break;
            }

            len = ret;
            ESP_LOGD(TAG, "%d bytes read", len);
            /* Print response directly to stdout as it is read */
            for(int i = 0; i < len; i++) {
                putchar(buf[i]);
            }
        } while(1);

    exit:
        esp_tls_conn_delete(tls);    
        putchar('\n'); // JSON output doesn't have a newline at end

        static int request_count;
        ESP_LOGI(TAG, "Completed %d requests", ++request_count);

        for(int countdown = 10; countdown >= 0; countdown--) {
            ESP_LOGI(TAG, "%d...", countdown);
            vTaskDelay(1000 / portTICK_PERIOD_MS);
        }
        ESP_LOGI(TAG, "Starting again!");
    }
}

void app_main(void)
{
    ESP_ERROR_CHECK( nvs_flash_init() );
    ESP_ERROR_CHECK(esp_netif_init());
    ESP_ERROR_CHECK(esp_event_loop_create_default());

    /* This helper function configures Wi-Fi or Ethernet, as selected in menuconfig.
     * Read "Establishing Wi-Fi or Ethernet Connection" section in
     * examples/protocols/README.md for more information about this function.
     */
    ESP_ERROR_CHECK(example_connect());

    xTaskCreate(&https_get_task, "https_get_task", 8192, NULL, 5, NULL);
}
